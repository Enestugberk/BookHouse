package com.rm.book.ui.allbooks;

import androidx.lifecycle.ViewModel;

public class AllbooklistViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}

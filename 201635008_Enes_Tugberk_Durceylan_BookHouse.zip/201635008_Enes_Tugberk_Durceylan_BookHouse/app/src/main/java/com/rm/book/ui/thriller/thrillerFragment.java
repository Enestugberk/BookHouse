package com.rm.book.ui.thriller;

import androidx.lifecycle.ViewModelProviders;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Toast;

import com.rm.book.MainActivity;
import com.rm.book.R;
import com.rm.book.database_access;
import com.rm.book.booklist.bookAdapter;
import com.rm.book.booklist.bookModel;
import com.rm.book.booklist.bookClick;

import java.util.List;

public class thrillerFragment extends Fragment {
    ListView list_item;

    private ThrillerViewModel mViewModel;

    public static thrillerFragment newInstance() {
        return new thrillerFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.thriller_fragment, container, false);
    }
    public static String mycategory = "Thriller";

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = ViewModelProviders.of(this).get(ThrillerViewModel.class);
        list_item = getView().findViewById(R.id.list_item);

        database_access acces = database_access.getInstance(getActivity().getApplicationContext());
        acces.open();
        List<bookModel> modelList= acces.getTable("select * from books where category='"+mycategory+"'");
        if(modelList.size()==0){
            Toast.makeText(getActivity(), "No Book Exists !", Toast.LENGTH_SHORT).show();
            return;
        }

        bookAdapter bookAdapter = new bookAdapter(getActivity(), modelList, new bookClick() {
            @Override
            public void onItemClick(bookModel model, int i) {
                if(i==2){
                    database_access acces = database_access.getInstance(getActivity().getApplicationContext());
                    acces.open();
                    acces.getText("delete from books where id="+model.getId());
                    acces.close();
                    MainActivity activity = (MainActivity) getActivity();
                    activity.navController.navigate(activity.navController.getCurrentDestination().getId());

                    Toast.makeText(getActivity(), "deleted", Toast.LENGTH_SHORT).show();
                    return;
                }
                Toast.makeText(getActivity(), ""+model.getTitle(), Toast.LENGTH_SHORT).show();

                MainActivity activity = (MainActivity) getActivity();

                Bundle args = new Bundle();
                args.putInt("id", model.getId());
                activity.navController.navigate(R.id.nav_bookgor,args);
            }
        });
        list_item.setAdapter(bookAdapter);

        Toast.makeText(getActivity(), mycategory+" Listed...", Toast.LENGTH_SHORT).show();
        acces.close();

        acces.close();
    }

}

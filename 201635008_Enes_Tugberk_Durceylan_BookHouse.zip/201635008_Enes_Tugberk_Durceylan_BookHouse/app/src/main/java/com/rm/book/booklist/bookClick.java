package com.rm.book.booklist;

public interface bookClick {
    void onItemClick(bookModel Button, int i);

}

package com.rm.book.ui.showbook;

import androidx.lifecycle.ViewModel;

public class ShowBookViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}

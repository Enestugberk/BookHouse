package com.rm.book.ui.showbook;

import androidx.lifecycle.ViewModelProviders;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.rm.book.R;
import com.rm.book.database_access;

public class showBookFragment extends Fragment {

    ImageView imageView2;
    Spinner spinner;
    Button btnAdd;
    TextView txttitle;
    TextInputEditText txtauthor;
    TextView txtbooksummary;

    private ShowBookViewModel mViewModel;

    public static showBookFragment newInstance() {
        return new showBookFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.show_book_fragment, container, false);
    }

    public int id = -1;

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = ViewModelProviders.of(this).get(ShowBookViewModel.class);

        if (getArguments() == null) {
            return;
        }
        id = getArguments().getInt("id", -1);

        if (id == -1) {
            Toast.makeText(getActivity(), "Book Bulunamadı ! ", Toast.LENGTH_SHORT).show();
            return;
        }

        imageView2 = getView().findViewById(R.id.imageView2);
        txttitle = getView().findViewById(R.id.txttitle);
        txtbooksummary = getView().findViewById(R.id.txtbooksummary);


        database_access acces = database_access.getInstance(getActivity().getApplicationContext());
        acces.open();

        txttitle.setText(acces.getText("select title from books where id=" + id));
        txtbooksummary.setText(acces.getText("select booksummary from books where id=" + id));

        String deger = acces.getText("select image from books where id=" + id);
        byte[] decodedString = Base64.decode(deger, Base64.DEFAULT);
        Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
        imageView2.setImageBitmap(decodedByte);


        acces.close();

    }

}

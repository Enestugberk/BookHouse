package com.rm.book.ui.thriller;

import androidx.lifecycle.ViewModel;

public class ThrillerViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}

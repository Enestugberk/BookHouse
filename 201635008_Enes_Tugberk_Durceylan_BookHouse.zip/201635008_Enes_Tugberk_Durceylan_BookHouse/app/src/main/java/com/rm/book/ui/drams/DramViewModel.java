package com.rm.book.ui.drams;

import androidx.lifecycle.ViewModel;

public class DramViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}

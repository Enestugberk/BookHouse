package com.rm.book.ui.addbook;

import androidx.lifecycle.ViewModelProviders;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.provider.MediaStore;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.rm.book.R;
import com.rm.book.database_access;

import java.io.ByteArrayOutputStream;

public class AddBookFragment extends Fragment {

    private AddBookViewModel mViewModel;
    ImageView imageView2;
    Spinner spinner;
    Button btnAdd;
    TextInputEditText txttitle;
    TextInputEditText txtauthor;
    TextInputEditText txtbooksummary;


    public static AddBookFragment newInstance() {
        return new AddBookFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.add_book_fragment, container, false);
    }

    String[] categories;

    public  static  String selectedCategory="Dedective";
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = ViewModelProviders.of(this).get(AddBookViewModel.class);


        imageView2 = getView().findViewById(R.id.imageView2);
        spinner = getView().findViewById(R.id.spinner);
        btnAdd = getView().findViewById(R.id.btnAdd);

        txttitle = getView().findViewById(R.id.txttitle);
        txtauthor = getView().findViewById(R.id.txtauthor);
        txtbooksummary = getView().findViewById(R.id.txtbooksummary);

        categories = getResources().getStringArray(R.array.category);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(),
                android.R.layout.simple_spinner_item, getActivity().getResources()
                .getStringArray(R.array.category));//setting the country_array to spinner
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
//if you want to set any action you can do in this listener
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int position, long id) {

                selectedCategory=categories[position];
                Toast.makeText(getActivity(), " Choosen Category " + categories[position], Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity(), "Loading please wait...", Toast.LENGTH_SHORT).show();

//                String category = spinner.getSelectedItem().toString();
                String title = txttitle.getText().toString();
                String author = txtauthor.getText().toString();
                String summary = txtbooksummary.getText().toString();

//                Bitmap bm=((BitmapDrawable)imageView2.getDrawable()).getBitmap();
//                byte[] imgpath=getBytesss(bm);

                imageView2.buildDrawingCache();
                Bitmap bitmap = imageView2.getDrawingCache();

                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.PNG, 90, stream);
                byte[] image = stream.toByteArray();
                System.out.println("byte array:" + image);

                String imgpath = Base64.encodeToString(image, 0);


                database_access acces = database_access.getInstance(getActivity().getApplicationContext());
                acces.open();
                acces.book_add("insert into books(title,author,booksummary,category,image) VALUES('" + title + "','" + author + "','" + summary + "','" + selectedCategory + "','" + imgpath + "')");

//                String deger = acces.getText("select image from books where title='"+title+"'");
//                byte[] decodedString = Base64.decode(deger, Base64.DEFAULT);
//                Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
//                imageView2.setImageBitmap(decodedByte);

                acces.close();


                Toast.makeText(getActivity(), "Added to "+selectedCategory , Toast.LENGTH_SHORT).show();

            }
        });


        imageView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(
                        Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

                startActivityForResult(i, RESULT_LOAD_IMAGE);
            }
        });
    }


    private static int RESULT_LOAD_IMAGE = 1;



    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == RESULT_LOAD_IMAGE && resultCode == getActivity().RESULT_OK && null != data) {
            Uri selectedImage = data.getData();
            String[] filePathColumn = {MediaStore.Images.Media.DATA};

            Cursor cursor = getActivity().getContentResolver().query(selectedImage,
                    filePathColumn, null, null, null);
            cursor.moveToFirst();

            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            String picturePath = cursor.getString(columnIndex);
            cursor.close();


            imageView2.setImageBitmap(BitmapFactory.decodeFile(picturePath));

        }


    }

}

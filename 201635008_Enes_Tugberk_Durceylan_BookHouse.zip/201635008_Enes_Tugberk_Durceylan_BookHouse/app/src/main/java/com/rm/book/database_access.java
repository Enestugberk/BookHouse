package com.rm.book;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.rm.book.booklist.bookModel;

import java.util.ArrayList;
import java.util.List;

public class database_access {
    private SQLiteOpenHelper openHelper;
    SQLiteDatabase db;
    static database_access instance;
    Cursor c = null;

    database_access(Context context) {
        this.openHelper = new database_helper(context);
    }

    public static database_access getInstance(Context context) {
        if (instance == null) {
            instance = new database_access(context);
        }
        return instance;
    }

    public void open() {
        this.db = openHelper.getWritableDatabase();
    }

    public void close() {
        if (db != null) {
            this.db.close();
            this.db.close();
        }
    }

    public String getText(String sql) { // top 1 ile ilk değeri döndürür
        c = db.rawQuery(sql, null);
        StringBuffer buffer = new StringBuffer();
        while (c.moveToNext()){
            String adress=c.getString(0);
            buffer.append(""+adress);
        }
        return  buffer.toString();
    }

    public void book_add(String sql) { // top 1 ile ilk değeri döndürür
       db.execSQL(sql);
    }

    public List<bookModel> getTable(String sql) {
        List<bookModel> modelList=new ArrayList<>();
        c = db.rawQuery(sql,null);
        while (c.moveToNext()){
            bookModel model = new bookModel();
            model.setId(c.getInt(0)); //id
            model.setTitle(c.getString(1)); //title
            model.setAuthor(c.getString(2));//author
            model.setBooksummary(c.getString(3));//booksummary
            model.setImage(c.getString(4));//image
            model.setCategory(c.getString(5));//category
            modelList.add(model);
        }
        return  modelList;
    }


}

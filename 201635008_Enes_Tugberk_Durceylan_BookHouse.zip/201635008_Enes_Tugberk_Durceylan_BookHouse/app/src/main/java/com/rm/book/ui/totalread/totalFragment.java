package com.rm.book.ui.totalread;

import androidx.lifecycle.ViewModelProviders;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.rm.book.R;
import com.rm.book.database_access;

public class totalFragment extends Fragment {

    private TotalViewModel mViewModel;
    Button btn_okuma;

    public static totalFragment newInstance() {
        return new totalFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.total_fragment, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = ViewModelProviders.of(this).get(TotalViewModel.class);


        btn_okuma = getView().findViewById(R.id.btn_okuma);

        database_access acces = database_access.getInstance(getActivity().getApplicationContext());
        acces.open();

        btn_okuma.setText(acces.getText("select count(*) as sayi from books"));

        acces.close();
    }

}

package com.rm.book.ui.addbook;

import androidx.lifecycle.ViewModel;

public class AddBookViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}

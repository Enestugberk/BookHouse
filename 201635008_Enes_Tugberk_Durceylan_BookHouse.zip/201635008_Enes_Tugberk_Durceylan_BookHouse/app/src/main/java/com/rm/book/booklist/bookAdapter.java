package com.rm.book.booklist;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;

import com.rm.book.R;

import java.util.List;

public class bookAdapter extends BaseAdapter {

    private List<bookModel> bookModels;
    private Context context;
    private LayoutInflater layoutInflater;
    private final bookClick listener;

    public bookAdapter(Context context, List<bookModel> bookModels, bookClick listener) {
        this.context = context;
        this.bookModels = bookModels;
        this.listener = listener;
        layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return bookModels.size();
    }

    @Override
    public Object getItem(int i) {
        return bookModels.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    bookModel bookModel1;

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = LayoutInflater.from(context).
                    inflate(R.layout.item_book, viewGroup, false);
        }

        // get current item to be displayed
        final bookModel currentItem = (bookModel) getItem(i);

        // get the TextView for item name and item description
        Button btnTitle = (Button) view.findViewById(R.id.btnTitle);
        Button btndelete = (Button) view.findViewById(R.id.btndelete);
        btnTitle.setText(currentItem.getTitle());


        btnTitle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onItemClick(currentItem,1);
            }
        });

        btndelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onItemClick(currentItem,2);
            }
        });

        // returns the view for the current row
        return view;
    }
}

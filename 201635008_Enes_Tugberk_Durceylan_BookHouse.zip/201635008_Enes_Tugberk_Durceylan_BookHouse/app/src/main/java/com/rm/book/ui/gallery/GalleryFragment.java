package com.rm.book.ui.gallery;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

import com.rm.book.MainActivity;
import com.rm.book.R;
import com.rm.book.database_access;
import com.rm.book.booklist.bookAdapter;
import com.rm.book.booklist.bookModel;
import com.rm.book.booklist.bookClick;

import java.util.List;

public class GalleryFragment extends Fragment {
    ListView list_item;
    private GalleryViewModel galleryViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        galleryViewModel =
                ViewModelProviders.of(this).get(GalleryViewModel.class);
        View root = inflater.inflate(R.layout.fragment_gallery, container, false);
//        final TextView textView = root.findViewById(R.id.text_gallery);
//        galleryViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
//            @Override
//            public void onChanged(@Nullable String s) {
//                textView.setText(s);
//            }
//        });
        return root;
    }

    public static String mycategory = "Romance";

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        list_item = getView().findViewById(R.id.list_item);

        database_access acces = database_access.getInstance(getActivity().getApplicationContext());
        acces.open();
        List<bookModel> modelList= acces.getTable("select * from books where category='"+mycategory+"'");
        if(modelList.size()==0){
            Toast.makeText(getActivity(), "No Book Exists !", Toast.LENGTH_SHORT).show();
            return;
        }

        bookAdapter bookAdapter = new bookAdapter(getActivity(), modelList, new bookClick() {
            @Override
            public void onItemClick(bookModel model, int i) {
                if(i==2){
                    database_access acces = database_access.getInstance(getActivity().getApplicationContext());
                    acces.open();
                    acces.getText("delete from books where id="+model.getId());
                    acces.close();
                    MainActivity activity = (MainActivity) getActivity();
                    activity.navController.navigate(activity.navController.getCurrentDestination().getId());

                    Toast.makeText(getActivity(), "deleted", Toast.LENGTH_SHORT).show();
                    return;
                }
                Toast.makeText(getActivity(), ""+model.getTitle(), Toast.LENGTH_SHORT).show();

                MainActivity activity = (MainActivity) getActivity();

                Bundle args = new Bundle();
                args.putInt("id", model.getId());
                activity.navController.navigate(R.id.nav_bookgor,args);
            }
        });
        list_item.setAdapter(bookAdapter);

        Toast.makeText(getActivity(), mycategory+" Listed...", Toast.LENGTH_SHORT).show();
        acces.close();

        acces.close();

    }
}

package com.rm.book.ui.totalread;

import androidx.lifecycle.ViewModel;

public class TotalViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}

package com.rm.book.ui.history;

import androidx.lifecycle.ViewModel;

public class HistoryViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
